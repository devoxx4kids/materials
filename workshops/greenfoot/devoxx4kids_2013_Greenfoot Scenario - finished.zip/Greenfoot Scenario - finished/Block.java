import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Block here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Block extends Actor
{

    public void collision(SnakeWorld world) {
        Greenfoot.playSound("dead.mp3");
        world.dead();
    }
}
